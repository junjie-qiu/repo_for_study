#include "type.h"
#include "stdio.h"

int main(int argc, char * argv[])
{
	__asm__ __volatile__("xchg %bx, %bx");
	int i = 0;
	while(1){
		while (i < 10000000) {
			i++;
		}
		printf("2\n");
		i = 0;
	}
	return 0;
	printf("/\n");
	return 0;
}
