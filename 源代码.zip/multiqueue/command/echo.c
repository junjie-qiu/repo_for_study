#include "stdio.h"

int main(int argc, char * argv[])
{
	__asm__ __volatile__("xchg %bx, %bx");
	int i;
	for (i = 1; i < argc; i++)
		printf("%s%s", i == 1 ? "" : " ", argv[i]);
	printf("\n");
	return 0;
}
