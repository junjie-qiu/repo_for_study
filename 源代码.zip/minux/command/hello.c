#include "stdio.h"

int main(int argc, char * argv[])
{
	__asm__ __volatile__("xchg %bx, %bx");
	printf("Hello World!\n");
	int pid = fork();
	if (pid != 0) { /* parent process */
		printf("parent is running, child pid:%d\n", pid);
		int s;
		int child = wait(&s);
		printf("child (%d) exited with status: %d.\n", child, s);
	}
	else {	/* child process */
		execl("/echo", "echo", "hello", "world", 0);
	}

	int i = 0;
	while(1){
		while (i < 10000000) {
			i++;
		}
		printf("1\n");
		//__asm__ __volatile__("xchg %bx, %bx");
		i = 0;
	}
	return 0;
}
